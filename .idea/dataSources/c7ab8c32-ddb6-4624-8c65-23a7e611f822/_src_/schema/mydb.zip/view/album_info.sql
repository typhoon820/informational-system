CREATE VIEW album_info AS
  SELECT
    `s`.`ID`   AS `song_id`,
    `s`.`name` AS `song_name`,
    `a`.`ID`   AS `album_id`,
    `a`.`name` AS `album_name`
  FROM ((`mydb`.`SONG` `s`
    JOIN `mydb`.`SONG_has_ALBUM` `sha` ON ((`s`.`ID` = `sha`.`song_id`))) JOIN `mydb`.`ALBUM` `a`
      ON ((`sha`.`album_id` = `a`.`ID`)));
