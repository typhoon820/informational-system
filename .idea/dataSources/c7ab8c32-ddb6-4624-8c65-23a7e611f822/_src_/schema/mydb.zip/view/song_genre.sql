CREATE VIEW song_genre AS
  SELECT
    `s`.`ID`    AS `song_id`,
    `s`.`name`  AS `song_name`,
    `g`.`ID`    AS `genre_id`,
    `g`.`genre` AS `genre_name`
  FROM (`mydb`.`SONG` `s`
    JOIN `mydb`.`GENRE` `g` ON ((`s`.`genre_id` = `g`.`ID`)));
